public class studenti {


    private String nome;

    private String cognome;

    private voti[] v;

    public studenti(String nome, String cognome) {

        this.nome = nome;
        this.cognome = cognome;
    }

    public void aggiungiVoto() {

        v = new voti[20];

    }


    public voti[] getV() {
        return v;
    }

    public String getNome() {
        return nome;
    }


    public String getCognome() {
        return cognome;
    }


}
