import java.util.Scanner;

public class Main {

    static Scanner in = new Scanner(System.in);
    public static void main(String[] args) {

        int numero;
        String nome, cognome, materia, data;


        System.out.println("nome studente");
        nome = in.next();
        System.out.println("cognome studente");
        cognome = in.next();

        studenti s = new studenti(nome, cognome);


        System.out.println("voto");
        numero = in.nextInt();
        System.out.println("data");
        data = in.next();
        System.out.println("materia");
        materia = in.next();
        






























    }
}