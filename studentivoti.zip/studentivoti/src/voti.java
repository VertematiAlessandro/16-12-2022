public class voti {


    private int numero;
    private String data;
    private String materia;

    public voti(int numero, String data, String materia ) {
        this.numero = numero;
        this.data = data;
        this.materia = materia;
    }


}
